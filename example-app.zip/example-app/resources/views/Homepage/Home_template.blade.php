<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Template</title>
</head>
<body>
      


        @include('Homepage.nav')
        @include('Homepage.Home_slideshow')
        @include ('Homepage.HomePage')
        @include('Homepage.SecondHomepage')
        @include ('Homepage.browse')
        @include ('Homepage.footer')

</body>
</html>