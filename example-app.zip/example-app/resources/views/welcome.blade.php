<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet"href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js">
    </script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js">
    </script>
    </head>
<body>
    
    <!--comment-->
    <section>
        <h2>Nita part</h2>
    </section>
    <!--comment-->
    <section>
        <h2>pisey part</h2>
    </section>
    <!--comment-->
    <section class="sptb bg-white mb-5">
    <div class="container p-0">
        <div class="section-title center-block text-center mt-4">
            <h3 class="font-weight-bold text-primary">BROWSE JOBS</h3>
        </div>
        <div class="panel panel-primary">
            <div class>
                <div class="tabs-menu">
                    <ul class="nav mb-6 d-flex justify-content-center mt-4">
                        <li class>
                            <a href="#category" class=" list-group-item 
                            list-group-item-action active 
                            border boder-4 rounded-pill mr-4 p-3 text-center text-dark text-decoration-none"style="width:130px " data-toggle="tab">Category</a>
                        </li>
                        <li class>
                            <a href="#industry" class=" list-group-item 
                            list-group-item-action 
                            border boder-4 rounded-pill  mr-4 p-3 text-center text-dark text-decoration-none"style="width:130px " data-toggle="tab">Industry</a>
                        </li>
                        <li class>
                            <a href="#location" class=" list-group-item 
                            list-group-item-action
                            border boder-4 rounded-pill  mr-4 p-3 text-center text-dark text-decoration-none"style="width:130px " data-toggle="tab">Location</a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="panel-body">
                <div class="tab-content">
                    <div class="tab-pane active " id="category">
                    <ul class="list-unstyled mb-0 row p-15 d-flex flex-row mt-5  ">
                        <li class="list-item col-sm-3 ">
                         <a href="https://jobboom.asia/position?category%5B%5D=1" class="text-dark float-left cursor-click text-decoration-none">
                            Accounting/Audit/Taxation
                         </a>
                        </li>
                        
                        <li class="list-item col-sm-3">
                         <a href="https://jobboom.asia/position?category%5B%5D=2" class="text-dark float-left cursor-click text-decoration-none">
                            Admin / Supervisory
                         </a>
                         
                        </li>

                        <li class="list-item col-sm-3">
                         <a href="https://jobboom.asia/position?category%5B%5D=5" class="text-dark float-left cursor-click text-decoration-none">
                            Agriculture
                         </a>
                         
                        </li>

                        <li class="list-item col-sm-3">
                        <a href="https://jobboom.asia/position?category%5B%5D=11" class="text-dark float-left cursor-click text-decoration-none">
                            Architecture
                        </a>
                        
                        </li>
                        <li class="list-item col-sm-3">
                        <a href="https://jobboom.asia/position?category%5B%5D=12" class="text-dark float-left cursor-click text-decoration-none">
                            Arts / Graphic Design
                        </a>
                        
                        </li>
                        <li class="list-item col-sm-3">
                        <a href="https://jobboom.asia/position?category%5B%5D=13" class="text-dark float-left cursor-click text-decoration-none">
                            Assistant
                        </a>
                        
                        </li>
                        <li class="list-item col-sm-3">
                        <a href="https://jobboom.asia/position?category%5B%5D=14" class="text-dark float-left cursor-click text-decoration-none">
                            Banking / Finance
                        </a>
                        
                        </li>
                        <li class="list-item col-sm-3">
                        <a href="https://jobboom.asia/position?category%5B%5D=15" class="text-dark float-left cursor-click text-decoration-none">
                            Business Administration
                        </a>
                        
                        </li>
                        <li class="list-item col-sm-3">
                        <a href="https://jobboom.asia/position?category%5B%5D=23" class="text-dark float-left cursor-click text-decoration-none">
                            Computer General
                       </a>
                        
                        </li>
                        <li class="list-item col-sm-3">
                        <a href="https://jobboom.asia/position?category%5B%5D=24" class="text-dark float-left cursor-click text-decoration-none">
                            Computer Networking
                        </a>
                        
                        </li>
                        <li class="list-item col-sm-3">
                        <a href="https://jobboom.asia/position?category%5B%5D=25" class="text-dark float-left cursor-click text-decoration-none">
                                            Computer Programming
                                        </a>
                                        
                        </li>
                        <li class="list-item col-sm-3"><a href="https://jobboom.asia/position?category%5B%5D=26" class="text-dark float-left cursor-click text-decoration-none">
                                            Construction
                                        </a>
                                        
                        </li><li class="list-item col-sm-3"><a href="https://jobboom.asia/position?category%5B%5D=28" class="text-dark float-left cursor-click text-decoration-none">
                                            Customer Service/Support
                                        </a>
                                        
                        </li><li class="list-item col-sm-3"><a href="https://jobboom.asia/position?category%5B%5D=29" class="text-dark float-left cursor-click text-decoration-none">
                                            Driving/Transport
                                        </a>
                                        
                        </li><li class="list-item col-sm-3"><a href="https://jobboom.asia/position?category%5B%5D=34" class="text-dark float-left cursor-click text-decoration-none">
                                            Engineer Electrical
                                        </a>
                                        
                        </li><li class="list-item col-sm-3"><a href="https://jobboom.asia/position?category%5B%5D=36" class="text-dark float-left cursor-click text-decoration-none">
                                            Engineering
                                        </a>
                                        
                        </li><li class="list-item col-sm-3"><a href="https://jobboom.asia/position?category%5B%5D=38" class="text-dark float-left cursor-click text-decoration-none">
                                            Exec. / Management
                                        </a>
                                       
                        </li><li class="list-item col-sm-3"><a href="https://jobboom.asia/position?category%5B%5D=43" class="text-dark float-left cursor-click text-decoration-none">
                                            Hotel/Restaurant
                                        </a>
                                       
                        </li><li class="list-item col-sm-3"><a href="https://jobboom.asia/position?category%5B%5D=44" class="text-dark float-left cursor-click text-decoration-none">
                                            HR
                                        </a>
                                        
                        </li><li class="list-item col-sm-3"><a href="https://jobboom.asia/position?category%5B%5D=50" class="text-dark float-left cursor-click text-decoration-none">
                                            Logistics
                                        </a>
                                        
                        </li><li class="list-item col-sm-3"><a href="https://jobboom.asia/position?category%5B%5D=51" class="text-dark float-left cursor-click text-decoration-none">
                                            Maintenance
                                        </a>
                                        
                        </li><li class="list-item col-sm-3"><a href="https://jobboom.asia/position?category%5B%5D=52" class="text-dark float-left cursor-click text-decoration-none">
                                            Manufacture / Operations
                                        </a>
                                        
                        </li><li class="list-item col-sm-3"><a href="https://jobboom.asia/position?category%5B%5D=56" class="text-dark float-left cursor-click text-decoration-none">
                                            Other
                                        </a>
                                       
                        </li><li class="list-item col-sm-3"><a href="https://jobboom.asia/position?category%5B%5D=57" class="text-dark float-left cursor-click text-decoration-none">
                                            Quality Control
                                        </a>
                                        
                        </li><li class="list-item col-sm-3"><a href="https://jobboom.asia/position?category%5B%5D=58" class="text-dark float-left cursor-click text-decoration-none">
                                            Research / Development
                                        </a>
                                        
                        </li><li class="list-item col-sm-3"><a href="https://jobboom.asia/position?category%5B%5D=61" class="text-dark float-left cursor-click text-decoration-none">
                                            Sales / Marketing
                                        </a>
                                        
                        </li><li class="list-item col-sm-3"><a href="https://jobboom.asia/position?category%5B%5D=69" class="text-dark float-left cursor-click text-decoration-none">
                                            Translation / Interpretation
                                        </a>
                                        
                        </li><li class="list-item col-sm-3"><a href="https://jobboom.asia/position?category%5B%5D=71" class="text-dark float-left cursor-click text-decoration-none">
                                            Website Development
                                        </a>
                                        
                        </li>  
                     </ul>
                                                                                                                                                                </ul>
                    </div>
                    <div class="tab-pane mb-6" id="industry">
                    <div class="row">
                    <ul class="list-unstyled mb-0 row p-15 d-flex flex-row mt-5 ">
                        <li class="list-item col-sm-3 ">
                         <a href="https://jobboom.asia/job?industry%5B%5D=28" class="text-dark float-left cursor-click text-decoration-none">
                            Accounting/Audition/Taxation
                         </a>
                        </li>
                        
                        <li class="list-item col-sm-3">
                         <a href="https://jobboom.asia/job?industry%5B%5D=8" class="text-dark float-left cursor-click text-decoration-none">
                            Agriculture
                         </a>
                         
                        </li>

                        <li class="list-item col-sm-3">
                         <a href="https://jobboom.asia/job?industry%5B%5D=36" class="text-dark float-left cursor-click text-decoration-none">
                            Architecture & Design
                         </a>
                         
                        </li>

                        <li class="list-item col-sm-3">
                        <a href="https://jobboom.asia/job?industry%5B%5D=27" class="text-dark float-left cursor-click text-decoration-none">
                            Automotive
                        </a>
                        
                        </li>
                        <li class="list-item col-sm-3">
                        <a href="https://jobboom.asia/job?industry%5B%5D=14" class="text-dark float-left cursor-click text-decoration-none">
                            Bank/Finance
                        </a>
                        
                        </li>
                        <li class="list-item col-sm-3">
                        <a href="https://jobboom.asia/job?industry%5B%5D=2" class="text-dark float-left cursor-click text-decoration-none">
                            Construction
                        </a>
                        
                        </li>
                        <li class="list-item col-sm-3">
                        <a href="https://jobboom.asia/job?industry%5B%5D=33" class="text-dark float-left cursor-click text-decoration-none">
                            Construction Material
                        </a>
                        
                        </li>
                        <li class="list-item col-sm-3">
                        <a href="https://jobboom.asia/job?industry%5B%5D=13" class="text-dark float-left cursor-click text-decoration-none">
                            Education
                        </a>
                        
                        </li>
                        <li class="list-item col-sm-3">
                        <a href="https://jobboom.asia/job?industry%5B%5D=37" class="text-dark float-left cursor-click text-decoration-none">
                            Electrical Supply
                       </a>
                        
                        </li>
                        <li class="list-item col-sm-3">
                        <a href="https://jobboom.asia/job?industry%5B%5D=25" class="text-dark float-left cursor-click text-decoration-none">
                            Entertainment
                        </a>
                        
                        </li>
                        <li class="list-item col-sm-3">
                        <a href="https://jobboom.asia/job?industry%5B%5D=9" class="text-dark float-left cursor-click text-decoration-none">
                                            Fisheries
                                        </a>
                                        
                        </li>
                        <li class="list-item col-sm-3"><a href="https://jobboom.asia/job?industry%5B%5D=15" class="text-dark float-left cursor-click text-decoration-none">
                                            Food & Beverages
                                        </a>
                                        
                        </li><li class="list-item col-sm-3"><a href="https://jobboom.asia/job?industry%5B%5D=23" class="text-dark float-left cursor-click text-decoration-none">
                                            Gambling & Casinos
                                        </a>
                                        
                        </li><li class="list-item col-sm-3"><a href="https://jobboom.asia/job?industry%5B%5D=24" class="text-dark float-left cursor-click text-decoration-none">
                                            Gas & oil
                                        </a>
                                        
                        </li><li class="list-item col-sm-3"><a href="https://jobboom.asia/job?industry%5B%5D=6" class="text-dark float-left cursor-click text-decoration-none">
                                            General Business
                                        </a>
                                        
                        </li><li class="list-item col-sm-3"><a href="https://jobboom.asia/job?industry%5B%5D=30" class="text-dark float-left cursor-click text-decoration-none">
                                            Gavernment Institution
                                        </a>
                                        
                        </li><li class="list-item col-sm-3"><a href="https://jobboom.asia/job?industry%5B%5D=7" class="text-dark float-left cursor-click text-decoration-none">
                                            Health & Beauty
                                        </a>
                                       
                        </li><li class="list-item col-sm-3"><a href="https://jobboom.asia/job?industry%5B%5D=22" class="text-dark float-left cursor-click text-decoration-none">
                                            Hospital & Nursing
                                        </a>
                                       
                        </li><li class="list-item col-sm-3"><a href="https://jobboom.asia/job?industry%5B%5D=32" class="text-dark float-left cursor-click text-decoration-none">
                                            Insurance
                                        </a>
                                        
                        </li><li class="list-item col-sm-3"><a href="https://jobboom.asia/job?industry%5B%5D=18" class="text-dark float-left cursor-click text-decoration-none">
                                            IT & Computer
                                        </a>
                                        
                        </li><li class="list-item col-sm-3"><a href="https://jobboom.asia/job?industry%5B%5D=17" class="text-dark float-left cursor-click text-decoration-none">
                                            Legal Service & Law Firm
                                        </a>
                                        
                        </li><li class="list-item col-sm-3"><a href="https://jobboom.asia/job?industry%5B%5D=1" class="text-dark float-left cursor-click text-decoration-none">
                                            Manufacturing
                                        </a>
                                        
                        </li><li class="list-item col-sm-3"><a href="https://jobboom.asia/job?industry%5B%5D=21" class="text-dark float-left cursor-click text-decoration-none">
                                            Media/Advertisement
                                        </a>
                                       
                        </li><li class="list-item col-sm-3"><a href="https://jobboom.asia/job?industry%5B%5D=10" class="text-dark float-left cursor-click text-decoration-none">
                                            Mining & Ecploration
                                        </a>
                                        
                        </li><li class="list-item col-sm-3"><a href="https://jobboom.asia/job?industry%5B%5D=29" class="text-dark float-left cursor-click text-decoration-none">
                                            NGO-Non Profit
                                        </a>
                                        
                        </li><li class="list-item col-sm-3"><a href="https://jobboom.asia/job?industry%5B%5D=35" class="text-dark float-left cursor-click text-decoration-none">
                                            Properity Development
                                        </a>
                                        
                        </li><li class="list-item col-sm-3"><a href="https://jobboom.asia/job?industry%5B%5D=31" class="text-dark float-left cursor-click text-decoration-none">
                                            Real Estate
                                        </a>
                                        
                        </li><li class="list-item col-sm-3"><a href="https://jobboom.asia/job?industry%5B%5D=26" class="text-dark float-left cursor-click text-decoration-none">
                                            Turism
                                        </a>
                                        
                        </li>  
                     </ul>
                     </div>
                     </div>
                     <div class="tab-pane mb-5" id="location">
                        <div class="row">
                    <ul class="list-unstyled mb-0 row p-15 d-flex flex-row mt-5 ">
                        <li class="list-item col-sm-3 ">
                         <a href="https://jobboom.asia/job?location%5B%5D=24" class="text-dark float-left cursor-click text-decoration-none">
                            Banteay Meanchey
                         </a>
                        </li>
                        
                        <li class="list-item col-sm-3">
                         <a href="https://jobboom.asia/job?location%5B%5D=3" class="text-dark float-left cursor-click text-decoration-none">
                            Battambang
                         </a>
                         
                        </li>

                        <li class="list-item col-sm-3">
                         <a href="https://jobboom.asia/job?location%5B%5D=15" class="text-dark float-left cursor-click text-decoration-none">
                            Kampong Cham
                         </a>
                         
                        </li>

                        <li class="list-item col-sm-3">
                        <a href="https://jobboom.asia/job?location%5B%5D=14" class="text-dark float-left cursor-click text-decoration-none">
                            Kampong Chnang
                        </a>
                        
                        </li>
                        <li class="list-item col-sm-3">
                        <a href="https://jobboom.asia/job?location%5B%5D=8" class="text-dark float-left cursor-click text-decoration-none">
                            Kampong Speu
                        </a>
                        
                        </li>
                        <li class="list-item col-sm-3">
                        <a href="https://jobboom.asia/job?location%5B%5D=13" class="text-dark float-left cursor-click text-decoration-none">
                            Kampong Thom
                        </a>
                        
                        </li>
                        <li class="list-item col-sm-3">
                        <a href="https://jobboom.asia/job?location%5B%5D=11" class="text-dark float-left cursor-click text-decoration-none">
                            Kampot
                        </a>
                        
                        </li>
                        <li class="list-item col-sm-3">
                        <a href="https://jobboom.asia/job?location%5B%5D=6" class="text-dark float-left cursor-click text-decoration-none">
                            Kandal
                        </a>
                        
                        </li>
                        <li class="list-item col-sm-3">
                        <a href="https://jobboom.asia/job?location%5B%5D=21" class="text-dark float-left cursor-click text-decoration-none">
                            Kep
                       </a>
                        
                        </li>
                        <li class="list-item col-sm-3">
                        <a href="https://jobboom.asia/job?location%5B%5D=17" class="text-dark float-left cursor-click text-decoration-none">
                            Kos Kong
                        </a>
                        
                        </li>
                        <li class="list-item col-sm-3">
                        <a href="https://jobboom.asia/job?location%5B%5D=1" class="text-dark float-left cursor-click text-decoration-none">
                                            Phnom Penh
                                        </a>
                                        
                        </li>
                        
                     </ul>
                     </div>                                                                                                                                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    
</Section>
<section class="sptb ">
    <footer class="bg-dark text-white">
        <div class="footer-main ">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-12">
                        <h6 class="mt-4">ABOUT JOBHINT</h6>
                        <hr class="deep-purple  accent-2 mb-3 mt-0 d-inline-block mx-auto">
                        <ul class="list-unstyled mb-0 text-muted">
                            <li>
                                <p>We’re on a mission to build a better future where technology creates good jobs for everyone. <br></p><p>
                            </p></li>
                        </ul>
                        
                    </div>
<div class="col-lg-3 col-md-12">
<h6 class="mt-4">OUR BLOG</h6>
<hr class="deep-purple  accent-2 mb-3 mt-0 d-inline-block mx-auto">
<ul class="list-unstyled mb-0 text-decoration-none text-white ">
	    	<li><a href="https://jobboom.asia/blog/ជំនាញដែលនិយោជិតត្រូវចាប់យកសម្រាប់ទីផ្សារការងារ-អនាគត" class="text-white">ជំនាញដែលនិយោជិតត្រូវចាប់យកសម្រាប់ទីផ្សារការងារ អនាគត</a></li>
        	<li><a href="https://jobboom.asia/blog/ធ្វើយ៉ាងណាដើម្បីបំពេញចន្លោះខ្វះខាតរវាងនិយោជក-និងនិយោជិត-" class="text-white">ធ្វើយ៉ាងណាដើម្បីបំពេញចន្លោះខ្វះខាតរវាងនិយោជក និងនិយោជិត?</a></li>
        	<li><a href="https://jobboom.asia/blog/វិធីគ្រប់គ្រងស្ត្រេសនៅកន្លែងការងារ" class="text-white">វិធីគ្រប់គ្រងស្ត្រេសនៅកន្លែងការងារ</a></li>
        	<li><a href="https://jobboom.asia/blog/រៀបចំតុធ្វើការបែបណាដើម្បីបង្កើនផលិតភាពការងារ" class="text-white">រៀបចំតុធ្វើការបែបណាដើម្បីបង្កើនផលិតភាពការងារ</a></li>
        	<li><a href="https://jobboom.asia/blog/រើសបុគ្គលិកលក្ខណៈល្អ-ជាជាងសមត្ថភាពតែម៉្យាង" class="text-white">រើសបុគ្គលិកលក្ខណៈល្អ ជាជាងសមត្ថភាពតែម៉្យាង</a></li>
        	<li><a href="https://jobboom.asia/blog/របៀបបង្ហាញសក្ដានុពលរបស់ខ្លួនសម្រាប់អ្នកបទពិសោធន៍តិចតួចស្ដួចស្ដើង" class="text-white">របៀបបង្ហាញសក្ដានុពលរបស់ខ្លួនសម្រាប់អ្នកបទពិសោធន៍តិចតួចស្ដួចស្ដើង</a></li>
</ul>
</div>
<div class="col-lg-3 col-md-12">
<h6 class="mt-4">RESOURCES</h6>
<hr class="deep-purple  accent-2 mb-3 mt-0 d-inline-block mx-auto text-decoration-none">
<ul class="list-unstyled mb-0">
			<li><a href="https://jobboom.asia/resource/how-to-create-your-cv-in-jobboom-app" class="text-white">How to create your CV in Jobboom App</a></li>
	    	</ul>
                    </div>

                    <div class="col-lg-3 col-md-12 pull-right">
                        <h6 class="mb-2 mt-4">EMAIL SUBSCRIBETION</h6>
                        <hr class="deep-purple  accent-2 mb-3 mt-0 d-inline-block mx-auto">
                        <form method="POST" action="https://jobboom.asia/subscriber" accept-charset="UTF-8">
                            <input type="hidden" name="_token" value="GdKfNfy5VxuFD7MBRLwymE0meflNg9Z2nkwDEtEr">                            <div class="input-group w-100">
                                <input type="new_sletter_email" name="new_sletter_email" required="" id="new_sletter_email" class="form-control " placeholder="Email">
                                <div class="input-group-append ">
                                    <button type="submit" class="btn btn-primary "> Subscribe </button>
                                </div>
                            </div>
                        </form>
                        
                    </div>
                </div>
            </div>
        </div>

        <div class="text-white p-0 border-top mt-4">
		<div class="container">
			<div class="p-2 text-center footer-links text-decoration-none "> 
									<a title="About us" target="_self" href="/about-us" class="text-white btn btn-link">About us</a>
									<a title="Contact us" target="_self" href="/contact-us" class="text-white btn btn-link">Contact us</a>
									<a title="Blogs" target="_self" href="/blog" class="text-white btn btn-link">Blogs</a>
									<a title="Resources" target="_self" href="/resource" class="text-white btn btn-link">Resources</a>
									<a title="Privacy &amp; Policy" target="_self" href="/privacy-policy" class="text-white btn btn-link">Privacy &amp; Policy</a>
									<a title="Term &amp; Condition" target="_self" href="/term-condition" class="text-white btn btn-link">Term &amp; Condition</a>
									<a title="Packages" target="_self" href="/packages" class="text-white btn btn-link">Packages</a>
				</div>
		</div>
	</div>
    <div class="text-white-50 border-top p-0">
            <div class="container">
                <div class="row d-flex footer_icon">
                    <div class="col-lg-12 col-sm-12  mt-3 mb-2 text-center ">
                        Powered by <a href="https://codeclans.asia" target="_blank">CODE CLANS</a> | © 2020 JOBHINT. All rights reserved. 
                                                 | 
                    <a class="social-icon" href="https://www.facebook.com/jobboomasia"><i class="fa fa-facebook"></i></a>
                    <a class="social-icon" href="https://www.linkedin.com/company/jobboomasia"><i class="fa fa-linkedin"></i></a>
                </div>

                </div>
            </div>
        </div>

    </footer>
</section>
<script>
        $(document).ready(function() {
    $('selector').click(function() {
        $('selector.active').removeClass("active");
        $(this).addClass("active");
    });
    });
</script>
   </body>
   </html>